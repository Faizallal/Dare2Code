from django.shortcuts import render
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from django.core import serializers
from django.conf import settings
import json

import joblib
vectorizer1 = joblib.load("C:\\TEMP\\API tutorial\\djangorest_project\\SampleProject\\Myapp\\vectorizer.sav")
model1 = joblib.load("C:\TEMP\API tutorial\djangorest_project\SampleProject\Myapp\model.sav")
#Text='Report RBP'
# Create your views here.

@api_view(["POST"])
def IdealWeight(heightdata):
    try:
        height=json.loads(heightdata.body)
        weight=str(height*10)
        return JsonResponse(weight,safe=False)
    except ValueError as e:
        return Response(e.args[0],status.HTTP400_BAD_REQUEST)

@api_view(["GET"])
def ComponentService(textdata):
    try:
        Text=json.loads(textdata.body)
        pred = model1.predict(vectorizer1.transform([Text]))[0]
        return JsonResponse(pred,safe=False)
    except ValueError as e:
        return Response(e.args[0],status.HTTP400_BAD_REQUEST)